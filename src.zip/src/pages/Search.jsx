import { useState } from 'react'
import { useEffect } from 'react'



function Search() {


  return (
    <>
        <h1>hola</h1>
     
    </>
  )
}

export default Search
