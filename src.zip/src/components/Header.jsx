import { useState } from 'react'
import { useEffect } from 'react'
import './Header.css'

function Header() {
  

  return (
    <>
     <h1 className='Titulo'>MONUMENTAPP</h1>
    </>
  )
}

export default Header
